import pandas as pd
import numpy as np
from sklearn.model_selection import train_test_split
from sklearn.linear_model import LinearRegression
from sklearn.metrics import r2_score,mean_squared_error
from sklearn.metrics.regression import mean_absolute_error


df = pd.read_csv("/Users/siwe9840/Desktop/winequality-red.csv")

X = np.array(df[['volatile acidity','density','sulphates','alcohol']])
y = np.array(df[['quality']])
t = np.array(df[['fixed acidity']])

X_train,X_test,y_train,y_test = train_test_split(X,y,test_size = 0.20,random_state=15)
mlr = LinearRegression()
mlr.fit(X_train,y_train)
y_pred = mlr.predict(X_test)

print('R2 score: %.2f' % r2_score(y_test,y_pred))
print('Mean squared error :',mean_squared_error(y_test,y_pred))
print('Mean absolute error :',mean_absolute_error(y_test,y_pred))

print(mlr.score(X_test,y_test))
print (mlr.intercept_)
print(mlr.coef_)

