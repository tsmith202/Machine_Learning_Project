import pandas as pd
import numpy as np
from sklearn.model_selection import train_test_split
from sklearn.naive_bayes import MultinomialNB
from sklearn.metrics import accuracy_score, confusion_matrix


df = pd.read_csv("/Users/siwe9840/Desktop/winequality-red.csv")

X = np.array(df[['volatile acidity','density','sulphates','alcohol']])
y = np.array(df[['quality']])
t = np.array(df[['fixed acidity']])

X_train,X_test,y_train,y_test = train_test_split(X,y,test_size = 0.20,random_state=15)
mlr = MultinomialNB()
mlr.fit(X_train,np.ravel(y_train))
y_pred = mlr.predict(X_test)

print(accuracy_score(y_test,y_pred))
print(confusion_matrix(y_test,y_pred))